@extends('layouts.default')
@section('content')
<p>You will find <b>test postback</b> file in resources/views/affiliate/apps/test-postback.blade.php</p>
@stop
<?php $__env->startSection('content'); ?>
<p>You will find <b>postbacks</b> file in resources/views/reports/postbacks.blade.php</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahulchouhan/Workspace/offerWall/resources/views/reports/postbacks.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<?php
   use Illuminate\Support\Facades\Http;
?>
<div class="bg-[#f2f2f2] p-[15px] lg:p-[35px]">
    <div class="bg-[#fff] p-[15px] md:p-[20px] rounded-[10px] mb-[20px]">
       <div class="flex items-center justify-between gap-[25px] w-[100%]  mb-[15px]">
          <h2 class="text-[20px] text-[#1A1A1A] font-[600]">Overview</h2>
          <button class="w-[100px] md:w-[110px] lg:w-[140px] bg-[#D272D2] px-[20px] py-[10px] w-[100px] rounded-[4px] text-[14px] font-[500] text-[#fff] text-center">Export</button>
       </div>
       <form method="get" id="postbackForm">

        <div class="w-full flex flex-col gap-[10px]">
            

            <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
                <label class="min-w-[160px] w-[100%] md:w-[10%] text-[14px] font-[500] text-[#898989] ">Range:</label>
                <input type="text" name="range"  class="dateRange w-[100%] bg-[#F6F6F6] px-[9px] py-[12px] text-[11px] font-[500] text-[#808080] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none" placeholder="Date" value="<?php echo e($urlForPagination['range'] ?? ''); ?>">
            </div>
        
            <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
                <label class="min-w-[160px] w-[100%] md:w-[10%] text-[14px] font-[500] text-[#898989] ">Apps:</label>
                <select name="appid" class="appendAffiliateApps w-[100%] xl:w-[90%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                   <option value="" >Select</option>
                   <?php if($allAffiliatesApp && $allAffiliatesApp->isNotEmpty()): ?>
                      <?php $__currentLoopData = $allAffiliatesApp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affiliateApp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($affiliateApp->id); ?>" <?php if(isset($urlForPagination['appid'])==$affiliateApp->id): ?> selected <?php endif; ?>><?php echo e($affiliateApp->appName); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endif; ?>
                </select>
            </div>


        <div class="w-[100%] flex items-center flex-wrap justify-start lg:flex-nowrap gap-[10px]">
                <label class="min-w-[160px] w-[10%] text-[14px] font-[500] text-[#898989] ">Filter by:</label>
                <div class="w-[100%] xl:w-[90%] flex flex-wrap xl:flex-nowrap  items-center gap-[5px] md:gap-[8px] lg:gap-[10px] xl:gap-[15px]">
                   <div class="relative w-[100%] xl:w-[80%] flex flex-wrap xl:flex-nowrap items-center gap-[10px]">
                   <div class="flex flex-wrap md:flex-nowrap items-start gap-[10px] w-[100%] xl:w-[33%]">
                <div class="w-[100%]">
                    <select name="status" class="filterByStatus bg-[#F6F6F6] px-[15px] py-[12px] text-[12px] font-[500] text-[#808080] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                        <option value="">Select</option>
                        <option value="1" <?php if(isset($urlForPagination['status']) && $urlForPagination['status']==1): ?> selected <?php endif; ?>>Confirmed</option>
                        <option value="0" <?php if(isset($urlForPagination['status']) && $urlForPagination['status']==2): ?> selected <?php endif; ?>>Rejected</option>
                    </select>
                </div>
            </div>

            <div class="flex flex-wrap md:flex-nowrap items-start gap-[10px] w-[100%] xl:w-[33%]">
                <div class="w-[100%]">
                    <select class="search-postback-filter w-[100%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none" name="offer">
                        <option value="">Select Offer </option>
                    <?php $__currentLoopData = $allOffers['offers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($offer['offer_id']); ?>" <?php if(isset($urlForPagination['offer']) && $urlForPagination['offer']==$offer['offer_id']): ?> selected <?php endif; ?>><?php echo e($offer['title']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="flex flex-wrap md:flex-nowrap items-start gap-[10px] w-[100%] xl:w-[33%]">
                <div class="w-[100%]">
                    <input type="text" name="goal"  class="goal-postback-filter w-[100%] bg-[#F6F6F6] px-[15px] py-[12px] text-[12px] font-[500] text-[#808080] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none" placeholder="Goal Name" value="<?php echo e($urlForPagination['goal'] ?? ''); ?>">
                </div>
            </div>
                   </div>
                   <div class="w-[100%] xl:w-[20%] flex items-center justify-start xl:justify-between gap-[10px]">
                    <button class="w-[80px] md:w-[90px] lg:w-[100px] xl:w-[130px] 2xl:w-[140px] bg-[#D272D2] px-[3px] py-[12px] w-[100px] rounded-[4px] text-[14px] font-[500] text-[#fff] text-center">Apply</button>
                        <a href="<?php echo e(route('report.postbacks')); ?>" class="w-[80px] md:w-[90px] lg:w-[100px] xl:w-[130px] 2xl:w-[140px] bg-[#F5EAF5] px-[20px] py-[10px] w-[100px] border border-[#FED5C3] rounded-[4px] text-[14px] font-[500] text-[#D272D2] text-center">Clear</a>
                   </div>
                </div></div>
             </div>




    </form>
       <div class="flex flex-col justify-between items-center gap-[5px] w-[100%] mt-[30px] ">
          <div class="w-[100%] overflow-x-scroll tableScroll">
             <table class="w-[100%] border-collapse border-spacing-0 rounded-[10px] border-separate border border-[#E6E6E6]">
                <tr>
                   <th class="bg-[#F6F6F6] rounded-tl-[10px] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap ">Postback URL</th>
                   <th class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">Conversion ID</th>
                   <th class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">Offer</th>
                   <th class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">Goal</th>
                   <th class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">Status</th>
                   <th class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">Payouts</th>
                   <th class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap"></th>
                   <th class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">HTTP code</th>
                   <th class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">Error</th>
                   <th class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">Date</th>
                   <th class="bg-[#F6F6F6] rounded-tr-[10px] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">ID</th>
                </tr>
                <?php if(!empty($allPostbacks['postbacks'])): ?>
                <?php $__currentLoopData = $allPostbacks['postbacks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postBacks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $url = env('AFFISE_API_END') . "offer/".$postBacks['offer_id'];
                  $response = HTTP::withHeaders([
                        'API-Key' => env('AFFISE_API_KEY'),
                  ])->get($url);
                  if ($response->successful()) {
                     $offerDetail = $response->json();
                     $offerName = $offerDetail['offer']['title'];
                  }else{
                     $offerName = 'N/A';
                  }
                ?>
                <tr>
                   <td title="https://uttdp.trckinnovative.com/postback/provider/YqJeA7iPuF?secure_key=rdEwgEyH7Z&uuid=925ac38213f9417289e43ce6ac85b376&transaction_id=679e8589f4b0420001df6b62&campaign_id=3680&payout=5.5" class="bigcontent text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-normal breakword"><?php echo e($postBacks['postback_url']); ?></td>
                   <td title="https://uttdp.trckinnovative.com/postback/provider/YqJeA7iPuF?secure_key=rdEwgEyH7Z&uuid=925ac38213f9417289e43ce6ac85b376&transaction_id=679e8589f4b0420001df6b62&campaign_id=3680&payout=5.5" class="bigcontent text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap "><?php echo e($postBacks['conversion_id']); ?></td>
                   <td title="https://uttdp.trckinnovative.com/postback/provider/YqJeA7iPuF?secure_key=rdEwgEyH7Z&uuid=925ac38213f9417289e43ce6ac85b376&transaction_id=679e8589f4b0420001df6b62&campaign_id=3680&payout=5.5" class="bigcontent text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap "><?php echo e($offerName); ?></td>
                   <td class="text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap "><?php echo e($postBacks['goal']); ?></td>
                   <td class="text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      <div class="inline-flex bg-[#F3FEE7] border border-[#BCEE89] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#6EBF1A] text-center uppercase">Success</div>
                   </td>
                   <td class="text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap "><?php echo e($postBacks['payouts'] ?? 'N/A'); ?></td>
                   <td class="text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">-</td>
                   <td class="text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap "><?php echo e($postBacks['http_code'] ?? 'N/A'); ?></td>
                   <td class="text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">-</td>
                   <td class="text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap "><?php echo e(date('d M Y', $postBacks['date']['sec'])); ?></td>
                   <td class="text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap "><?php echo e($postBacks['_id']['$id']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
             </table>
         </div>
         <div class="pagination mt-[20px] flex flex-wrap gap-[10px] items-center justify-end">
            <?php if($prevPage): ?>
            <?php 
            $urlForPagination['page'] =$nextPage;
            ?>
                <a href="<?php echo e(route('report.postbacks', $urlForPagination)); ?>" class="btn group inline-flex gap-[8px] items-center bg-[#F5EAF5] border border-[#FED5C3] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#D272D2] text-center hover:bg-[#D272D2] hover:text-[#fff]">
                    <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 1L1 5L5 9" stroke="#D272D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="group-hover:stroke-[#fff]" />
                    </svg> Previous
                </a>
            <?php endif; ?>
        
            <?php
                $totalPages = ceil($totalCount / $perPage);
                $range = 3; // Number of pages to display before and after the current page
                $start = max($currentPage - $range, 1);
                $end = min($currentPage + $range, $totalPages);
            ?>
        
            <?php if($start > 1): ?>
            <?php 
            $urlForPagination['page'] =1;
            ?>
                <a href="<?php echo e(route('report.postbacks', $urlForPagination)); ?>" class="btn inline-flex gap-[8px] items-center bg-[#fff] border border-[#E6E6E6] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#808080] text-center hover:bg-[#D272D2] hover:text-[#fff]">
                    1
                </a>
                <?php if($start > 2): ?>
                    <span class="text-[#808080] px-[5px]">...</span>
                <?php endif; ?>
            <?php endif; ?>
        
            <?php for($i = $start; $i <= $end; $i++): ?>
            <?php 
            $urlForPagination['page'] =$i;
            ?>
                <a href="<?php echo e(route('report.postbacks', $urlForPagination)); ?>" class="<?php echo e($i == $currentPage ? 'btn-active btn inline-flex gap-[8px] items-center bg-[#fff] border border-[#E6E6E6] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#808080] text-center hover:bg-[#D272D2] hover:text-[#fff]' : 'btn inline-flex gap-[8px] items-center bg-[#fff] border border-[#E6E6E6] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#808080] text-center hover:bg-[#D272D2] hover:text-[#fff]'); ?>">
                    <?php echo e($i); ?>

                </a>
            <?php endfor; ?>
        
            <?php if($end < $totalPages): ?>
                <?php if($end < $totalPages - 1): ?>
                    <span class="text-[#808080] px-[5px]">...</span>
                <?php endif; ?>
                <?php 
                $urlForPagination['page'] =$totalPages;
                ?>
                <a href="<?php echo e(route('report.postbacks', $urlForPagination)); ?>" class="btn inline-flex gap-[8px] items-center bg-[#fff] border border-[#E6E6E6] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#808080] text-center hover:bg-[#D272D2] hover:text-[#fff]">
                    <?php echo e($totalPages); ?>

                </a>
            <?php endif; ?>
        
            <?php if($nextPage): ?>
            <?php 
                $urlForPagination['page'] =$nextPage;
                ?>
                <a href="<?php echo e(route('report.postbacks', $urlForPagination)); ?>" class="btn group inline-flex gap-[5px] items-center bg-[#F5EAF5] border border-[#FED5C3] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#D272D2] text-center hover:bg-[#D272D2] hover:text-[#fff]">
                    Next
                    <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1L5 5L1 9" stroke="#D272D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="group-hover:stroke-[#fff]" />
                    </svg>
                </a>
            <?php endif; ?>
        </div>
       </div>
    </div>
</div>
<script>
    $('.filterByStatus').select2({
        placeholder: "Select status",
        allowClear: true // Adds a clear (X) button
    });
    $('#postbackForm').on('submit',function(){
        $('.loader-fcustm').show();
    });
    $('.search-postback-filter').select2({
        placeholder: "Select an offer",
        allowClear: true // Adds a clear (X) button
    });

    $(document).ready(function() {
        $('.appendAffiliateApps').select2({
            placeholder: "Select an app",
            allowClear: true // Adds a clear (X) button
        });
   });
   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahulchouhan/Workspace/offerwall-affiliate/resources/views/reports/postbacks.blade.php ENDPATH**/ ?>
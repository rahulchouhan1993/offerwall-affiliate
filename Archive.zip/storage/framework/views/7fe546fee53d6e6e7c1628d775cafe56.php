<?php $__env->startSection('content'); ?>
<p>You will find <b>report permission</b> file in resources/views/admin/reports/</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahulchouhan/Workspace/offerWall/resources/views/admin/reports/permission.blade.php ENDPATH**/ ?>
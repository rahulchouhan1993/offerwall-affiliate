<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="Googlebot-News" content="noindex, nnofollow">
	    <meta name="googlebot" content="noindex, nofollow">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>OfferWall-Affiliate | <?php echo e($pageTitle); ?></title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <!-- Fonts -->
        <link rel="icon" type="image/x-icon" href="/images/favicon.png">
        <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"rel="stylesheet"/>
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <!-- Styles / Scripts -->
        <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?> 
        <?php endif; ?>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet"/>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    </head>
    <body class="font-sans antialiased dark:bg-black dark:text-white/50">
        <div class="loader-fcustm fixed inset-0 flex flex-col items-center justify-center bg-white bg-opacity-75 backdrop-blur-md z-50">
            <div class="w-10 h-10 border-4 border-[#D272D2] border-t-transparent rounded-full animate-spin"></div>
            <p class="mt-4 text-lg font-semibold text-[#D272D2]">Loading...</p>
        </div>
        <script>
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>");
            <?php endif; ?>
        
            <?php if(session('error')): ?>
                toastr.error("<?php echo e(session('error')); ?>");
            <?php endif; ?>
        </script>
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pt-[50px] md:pt-[80px] flex dashboardMain">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="dashboardContainer bg-[#F2F2F2]  pb-[100px]">
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const button = document.getElementById('menuToggle');

                button.addEventListener('click', function() {
                    document.body.classList.toggle('active');
                });
            });

            document.addEventListener("DOMContentLoaded", function() {
                document.querySelectorAll("a").forEach(link => {
                    link.addEventListener("click", function(event) {
                        // Only show loading if the link is navigating away from the page
                        if (this.href && this.target !== "_blank" && this.href!='javascript:void(0);' && this.href!='#') {
                            $('.loader-fcustm').show()
                        }
                    });
                });

                // Hide loading overlay when page is fully loaded
                window.onload = function() {
                    $('.loader-fcustm').fadeOut(1000)
                };
            });
            $(document).ready(function() {
                $('.sel2fld').select2({
                    placeholder: "Select an option",
                    allowClear: true // Adds a clear (X) button
                });
            });
            
            $(function() {
                $('.dateRange').daterangepicker({
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                    },
                    startDate: moment().subtract(6, 'days'),  // Default start date (7 days ago)
                    endDate: moment(),  
                    opens: 'right'
                }, function(start, end, label) {
                    console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
                });
            });
        </script>
    </body>
</html><?php /**PATH /Users/rahulchouhan/Workspace/offerwall-affiliate/resources/views/layouts/default.blade.php ENDPATH**/ ?>
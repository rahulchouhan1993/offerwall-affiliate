<?php $__env->startSection('content'); ?>
<p>You will find <b>test postback</b> file in resources/views/affiliate/apps/test-postback.blade.php</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.affiliate.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahulchouhan/Workspace/offerWall/resources/views/Affiliate/apps/test-postback.blade.php ENDPATH**/ ?>
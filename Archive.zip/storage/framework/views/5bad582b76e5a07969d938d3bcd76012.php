<?php $__env->startSection('content'); ?>
<p>You will find <b>content</b> file in resources/views/affiliate/dashboard/index.blade.php</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.affiliate.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahulchouhan/Workspace/offerWall/resources/views/Affiliate/dashboard/index.blade.php ENDPATH**/ ?>
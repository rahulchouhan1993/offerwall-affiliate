<?php $__env->startSection('content'); ?>
<div class="bg-[#f2f2f2] p-[15px] md:p-[35px]">
    <div class="bg-[#fff] p-[15px] md:p-[20px] rounded-[10px] mb-[20px]">
       <div class="flex items-center justify-between gap-[25px] w-[100%]  mb-[15px]">
          <h2 class="text-[20px] text-[#1A1A1A] font-[600]">Graph & Statistics</h2>
          <button class="w-[100px] md:w-[110px] lg:w-[140px] bg-[#D272D2] px-[20px] py-[10px] w-[100px] rounded-[4px] text-[14px] font-[500] text-[#fff] text-center">Export</button>
       </div>
       <form method="get" id="filterStats" >
       <div class="flex flex-col items-center justify-center gap-[15px]">
          <div class="w-full flex flex-col gap-[10px]">
            <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
               <label class="min-w-[160px] w-[100%] md:w-[10%] text-[14px] font-[500] text-[#898989] ">Apps:</label>
               <select name="appid" class="appendAffiliateApps w-[100%] lg:w-[90%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                  <option value="" >Select</option>
                  <?php if($allAffiliatesApp && $allAffiliatesApp->isNotEmpty()): ?>
                     <?php $__currentLoopData = $allAffiliatesApp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affiliateApp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($affiliateApp->id); ?>" <?php if($filterByAffApp==$affiliateApp->id): ?> selected <?php endif; ?>><?php echo e($affiliateApp->appName); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               </select>
            </div>
             <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
                <label
                   class="min-w-[160px] w-[100%] md:w-[10%] text-[14px] font-[500] text-[#898989] ">Group by:</label>
                <select name="groupBy" class="groupby-fltr w-[100%] lg:w-[90%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                   <option value="hour" <?php if($recordGroupBy=='hour'): ?> selected <?php endif; ?>>Hour</option>
                   <option value="day" <?php if($recordGroupBy=='day'): ?> selected <?php endif; ?>>Date</option>
                   <option value="month" <?php if($recordGroupBy=='month'): ?> selected <?php endif; ?>>Month</option>
                   <option value="country" <?php if($recordGroupBy=='country'): ?> selected <?php endif; ?>>Country</option>
                   <option value="browser" <?php if($recordGroupBy=='browser'): ?> selected <?php endif; ?>>Browser</option>
                   <option value="device" <?php if($recordGroupBy=='device'): ?> selected <?php endif; ?>>Device Brand</option>
                   <option value="device_model" <?php if($recordGroupBy=='device_model'): ?> selected <?php endif; ?>>Device Model</option>
                   <option value="os" <?php if($recordGroupBy=='os'): ?> selected <?php endif; ?>>Device OS</option>
                   <option value="offer" <?php if($recordGroupBy=='offer'): ?> selected <?php endif; ?>>Offer</option>
                </select>
             </div>
             <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
                <label class="min-w-[160px] w-[10%] text-[14px] font-[500] text-[#898989] ">Range:</label>
                <input name="range" class="dateRange w-[100%] lg:w-[90%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none" type="text" value="<?php echo e($completeDate); ?>" />
             </div>
             <div class="w-[100%] flex flex-wrap lg:flex-nowrap items-start xl:items-center justify-between gap-[10px]">
                <label class="min-w-[160px] w-[100%] lg:w-[10%] text-[14px] font-[500] text-[#898989] ">Filter by:</label>
                <div class="w-[100%] xl:w-[85%] 2xl:w-[90%] flex justify-between flex-wrap xl:flex-nowrap  items-center gap-[5px] md:gap-[8px] lg:gap-[10px] xl:gap-[15px]">
                   <div class="w-[100%] lg:w-[100%] xl:w-[60.5%]  2xl:w-[70.7%] flex flex-wrap xl:flex-nowrap items-center gap-[10px]">
                      <select name="filterBy" class="filterByDrop w-[100%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                        <option value="">Select</option>
                        <option value="country">Country</option>
                        
                        <option value="os" >Operating System</option>
                        <option value="offer" >Offer</option>
                      </select>
                      <select  class="search-input-filter w-[100%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none" name="filterByValue">
                      </select>
                      
                      
                   </div>
                   <div class="w-[100%] lg:w-[100%] xl:w-[24%] 2xl:w-[24%] flex items-center justify-end  gap-[10px]">

                   <a href="javascript:void(0);" class="addCustomFilter w-[90px] xl:w-[120px] bg-[#D272D2] px-[20px] py-[11px] w-[100px] rounded-[4px] text-[14px] font-[500] text-[#fff] text-center" >Add</a>
                      <button
                         class="w-[140px] bg-[#D272D2] px-[20px] py-[11px] w-[90px] xl:w-[120px] rounded-[4px] text-[14px] font-[500] text-[#fff] text-center" type="submit">Apply</button>
                      <a href="<?php echo e(route('report.statistics')); ?>"
                         class="w-[140px] bg-[#F5EAF5] px-[20px] py-[11px] w-[90px] xl:w-[120px] border border-[#F5EAF5] rounded-[4px] text-[14px] font-[500] text-[#D272D2] text-center" >Clear</a>
                   </div>
                </div>
             </div>
             <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
               <label class="min-w-[160px] w-[10%] text-[14px] font-[500] text-[#898989] ">Active filters:</label>
                  <div class="w-[90%] flex flex-wrap items-center gap-[10px] allFilterInCommon">
                     <?php if(!empty($filterByValue)): ?>
                        <?php $__currentLoopData = $filterByValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $inValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center gap-[20px] bg-[#F6F6F6] pl-[15px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none"> <input type="hidden" name="filterIn[<?php echo e($k); ?>][]" value="<?php echo e($inValue[0]); ?>"><input type="hidden" name="filterInValue[<?php echo e($k); ?>][]" value="<?php echo e($filterByText[$k][0]); ?>"> <?php echo e($filterByText[$k][0]); ?> 
                        <button class="removeActiveOne w-[40px] h-[40px] flex items-center justify-center gap-[5px] bg-[#D272D2] text-[#fff] border-l-[1px] border-l-[#E6E6E6]"> <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M10.4033 1.29822L0.999773 10.7018" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" /> <path d="M10.4033 10.7018L0.999772 1.29822" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" /> </svg> </button> </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>
                  </div>
             </div>
          </div>
       </div>
       </form>
       <div class="my-[20px]">
          <canvas id="statisticsGraph"></canvas>
       </div> 
      <?php 
         $headingArray = ['hour' => 'Hour','day' => 'Day','month' => 'Month','country' => 'Country','browser' => 'Browsers','device' => 'Devices','device_model' => 'Device Model','os' => 'Operating System'];
      ?>
      <div class="flex flex-col justify-between items-center gap-[5px] w-[100%] mt-[30px] ">
          <div class="w-[100%] overflow-x-scroll tableScroll">
             <table
                class="w-[100%] border-collapse border-spacing-0 rounded-[10px] border-separate border border-[#E6E6E6]">
                <tr>
                   <th
                      class="bg-[#F6F6F6] rounded-tl-[10px] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap ">
                      <?php echo e($headingArray[$recordGroupBy] ?? 'Hour'); ?>

                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Views
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Clicks
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Conversions
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      CVR
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      EPC
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      EPU
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[14px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Payout
                   </th>
                </tr>
                <?php if(!empty($allStatistics['stats'])): ?>
                <?php $__currentLoopData = $allStatistics['stats']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>
                   <td
                      class="border-b-[1px] border-b-[#E6E6E6] text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      <?php echo e($stats['slice'][$recordGroupBy]); ?>

                   </td>
                   <td
                      class="border-b-[1px] border-b-[#E6E6E6] text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      <?php echo e($stats['views']); ?>

                   </td>
                   <td
                      class="border-b-[1px] border-b-[#E6E6E6] text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      <?php echo e($stats['traffic']['uniq'] ?? 'N/A'); ?>

                   </td>
                   <td
                      class="border-b-[1px] border-b-[#E6E6E6] text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                       <?php echo e($stats['actions']['confirmed']['count'] ?? 'N/A'); ?>

                   </td>
                   <?php 
                     $confirmCount = $stats['actions']['confirmed']['count'] ?? 0; 
                     $trafficCount = $stats['traffic']['uniq'] ?? 0;
                     if($trafficCount>0){
                        $percentage = number_format(($confirmCount / $trafficCount) * 100, 2).' %';
                     }else{
                        $percentage = 'N/A';
                     }
                  ?>
                   <td
                      class="border-b-[1px] border-b-[#E6E6E6] text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      <?php echo e($percentage); ?> 
                   </td>
                   <td
                      class="border-b-[1px] border-b-[#E6E6E6] text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      $ <?php echo e($stats['affiliate_epc'] ?? 'N/A'); ?>

                   </td>
                   <td
                      class="border-b-[1px] border-b-[#E6E6E6] text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      N/A
                   </td>
                   <td
                      class="border-b-[1px] border-b-[#E6E6E6] text-[14px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      $ <?php echo e($stats['epc'] ?? 'N/A'); ?>

                   </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
             </table>
          </div>
          
       </div>
    </div>
 </div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const ctx = document.getElementById('statisticsGraph').getContext('2d');

        fetch("<?php echo e(route('chart.data')); ?>")
            .then(response => response.json())
            .then(data => {
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: data.labels, // Dynamic labels from API
                        datasets: [
                            {
                                label: 'Rounded Line Dataset',
                                data: data.lineData, // Dynamic data from API
                                borderColor: 'rgba(75, 192, 192, 1)',
                                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                borderWidth: 2,
                                tension: 0.6, // Smoothness of the line (rounded effect)
                                fill: true, // Optional: Fill area under the line
                                pointRadius: 5, // Point size
                                pointBackgroundColor: 'rgba(75, 192, 192, 1)'
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                display: true,
                                position: 'top'
                            },
                            tooltip: {
                                enabled: true // Show tooltips on hover
                            }
                        },
                        scales: {
                            x: {
                                title: {
                                    display: true,
                                    text: 'Months'
                                }
                            },
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Values'
                                }
                            }
                        }
                    }
                });
            })
            .catch(error => console.error('Error fetching chart data:', error));
   });

   

   $(document).on('change','.filterByDrop',function(){
      $('.loader-fcustm').show();
      $.ajax({
         headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         },
         url: '<?php echo e(route("filterGroup")); ?>/'+$(this).val(), // URL to send request
         type: 'GET', // HTTP method
         success: function (response) {
            $('.loader-fcustm').hide();
            $('.search-input-filter').html(response).select2({
               placeholder: "Select a filter by option",
               allowClear: true // Adds a clear (X) button
            });;
         },
         error: function (xhr) {
            $('#response').html('<p>An error occurred. Please try again.</p>');
         }
      });
   });

   $(document).on('click','.addCustomFilter',function(){
      if($('.search-input-filter').val()!='' && $('.filterByDrop').val()!=''){
         $('.allFilterInCommon').append('<div class=" flex items-center gap-[20px] bg-[#F6F6F6] pl-[15px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none"><input type="hidden" name="filterIn['+$('.filterByDrop').val()+'][]" value="'+$('.search-input-filter').val()+'"><input type="hidden" name="filterInValue['+$('.filterByDrop').val()+'][]" value="'+$('.search-input-filter option:selected').text()+'"> '+$('.search-input-filter option:selected').text()+' <button class="w-[40px] h-[40px] flex items-center justify-center gap-[5px] bg-[#D272D2] text-[#fff] border-l-[1px] border-l-[#E6E6E6]"> <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M10.4033 1.29822L0.999773 10.7018" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" /> <path d="M10.4033 10.7018L0.999772 1.29822" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" /> </svg> </button> </div>');
         $('.search-input-filter').val('');
      }
   });

   $('#filterStats').on('submit',function(){
      $('.loader-fcustm').show();
   })

   $(document).on('click','.removeActiveOne',function(){
      $(this).parent().remove();
   });

   $('.appendAffiliateApps').select2({
      placeholder: "Select an app",
      allowClear: true // Adds a clear (X) button
   });

   $('.filterByDrop').select2({
      placeholder: "Select a filter by option",
      allowClear: true // Adds a clear (X) button
   });

   $('.search-input-filter').select2({
      placeholder: "Select a filter by option",
      allowClear: true // Adds a clear (X) button
   });

   $('.groupby-fltr').select2({
      placeholder: "Select group by option",
      allowClear: true // Adds a clear (X) button
   });

   
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahulchouhan/Workspace/offerwall-affiliate/resources/views/reports/statistics.blade.php ENDPATH**/ ?>
<div class="w-[100%] px-[15px] py-[15px] md:px-[25px] md:py-[25px] lg:px-[35px] lg:py-[35px] text-[14px] font-[400] text-[#919191] bg-[#fff] fixed bottom-[0]">
&copy; copyright 2024
</div><?php /**PATH /Users/rahulchouhan/Workspace/offerwall/resources/views/layouts/admin/footer.blade.php ENDPATH**/ ?>
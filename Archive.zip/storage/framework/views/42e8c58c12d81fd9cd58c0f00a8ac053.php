<?php $__env->startSection('content'); ?>


<div class="bg-[#f2f2f2] p-[15px] md:p-[35px]">
    <div class="bg-[#fff] p-[15px] md:p-[20px] rounded-[10px] mb-[20px]">
       <div class="flex items-center justify-between gap-[25px] w-[100%]  mb-[15px]">
          <h2 class="text-[20px] text-[#1A1A1A] font-[600]">Overview</h2>
          <button
             class="w-[140px] bg-[#D272D2] px-[20px] py-[10px] w-[100px] rounded-[4px] text-[14px] font-[500] text-[#fff] text-center">Export</button>
       </div>
       <div class="flex flex-col items-center justify-center gap-[15px]">
         <form method="get" id="filterConversions">
          <div class="w-full flex flex-col gap-[10px]">
            <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
               <label class="min-w-[160px] w-[100%] md:w-[10%] text-[14px] font-[500] text-[#898989] ">Apps:</label>
               <select name="appid" class="appendAffiliateApps w-[100%] lg:w-[90%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                  <option value="" >Select</option>
                  <?php if($allAffiliatesApp && $allAffiliatesApp->isNotEmpty()): ?>
                     <?php $__currentLoopData = $allAffiliatesApp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affiliateApp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($affiliateApp->id); ?>" <?php if($filterOptions['filterByAffApp']==$affiliateApp->id): ?> selected <?php endif; ?>><?php echo e($affiliateApp->appName); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               </select>
            </div>
             <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
                <label class="min-w-[160px] w-[100%] md:w-[10%] text-[14px] font-[500] text-[#898989] ">Range:</label>
                <input type="text" name="range" class="dateRange w-[100%] lg:w-[90%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none"
                   placeholder="2024-12-10" value="<?php echo e($filterOptions['completeDate']); ?>">
             </div>
             <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
                <label class="min-w-[160px] w-[10%] text-[14px] font-[500] text-[#898989] ">Country:</label>
                <select name="country" class="countryOptions w-[100%] lg:w-[90%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                  <option value="">Select</option>
                  <?php $__currentLoopData = $allCountry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($country->iso); ?>" <?php if($filterOptions['country'] == $country->iso): ?> selected <?php endif; ?>><?php echo e($country->nicename); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
             </div>
             <div class="w-[100%] flex items-center flex-wrap justify-start lg:flex-nowrap gap-[10px]">
                <label class="min-w-[160px] w-[10%] text-[14px] font-[500] text-[#898989] ">Filter by:</label>
                <div class="w-[100%] xl:w-[90%] flex flex-wrap xl:flex-nowrap  items-center gap-[5px] md:gap-[8px] lg:gap-[10px] xl:gap-[15px]">
                   <div class="relative w-[100%] xl:w-[80%] flex flex-wrap xl:flex-nowrap items-center gap-[10px]">
                      <select name="offer"
                         class="offerOption w-[100%] xl:w-[25%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                         <option value="">Select</option>
                         <?php $__currentLoopData = $allOffers['offers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($offer['offer_id']); ?>" <?php if($filterOptions['offer'] == $offer['id']): ?> selected <?php endif; ?>><?php echo e($offer['title'].' ('.$offer['offer_id'].')'); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <select name="os"
                         class="osOption w-[100%] xl:w-[25%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                         <option value="">Select</option>
                         <option value="Windows" <?php if($filterOptions['os'] == 'Windows'): ?> selected <?php endif; ?>>Windows</option>
                         <option value="macOS" <?php if($filterOptions['os'] == 'macOS'): ?> selected <?php endif; ?>>macOS</option>
                         <option value="Linux" <?php if($filterOptions['os'] == 'Linux'): ?> selected <?php endif; ?>>Linux</option>
                         <option value="Android" <?php if($filterOptions['os'] == 'Android'): ?> selected <?php endif; ?>>Android</option>
                         <option value="iOS" <?php if($filterOptions['os'] == 'iOS'): ?> selected <?php endif; ?>>iOS</option>
                      </select>
                      <select name="status"
                         class="conversionstatusOption w-[100%] xl:w-[25%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                         <option value="">Select</option>
                         <option value="1" <?php if($filterOptions['status'] == '1'): ?> selected <?php endif; ?>>Confirmed</option>
                         <option value="2" <?php if($filterOptions['status'] == '2'): ?> selected <?php endif; ?>>Pending</option>
                         <option value="3" <?php if($filterOptions['status'] == '3'): ?> selected <?php endif; ?>>Declined</option>
                         <option value="5" <?php if($filterOptions['status'] == '5'): ?> selected <?php endif; ?>>Hold</option>
                      </select>
                      <input name="goal" class="w-[100%] xl:w-[25%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none" placeholder="Goal" value="<?php echo e($filterOptions['goal']); ?>">
                      
                   </div>
                   <div class="w-[100%] xl:w-[20%] flex items-center justify-start xl:justify-between gap-[10px]">
                      <button
                         class="w-[140px] bg-[#D272D2] px-[20px] py-[11px] w-[100px] rounded-[4px] text-[14px] font-[500] text-[#fff] text-center">Apply</button>
                      <a href="<?php echo e(route('report.conversions')); ?>"
                         class="w-[140px] bg-[#F5EAF5] px-[20px] py-[11px] w-[100px] border border-[#F5EAF5] rounded-[4px] text-[14px] font-[500] text-[#D272D2] text-center">Clear</a>
                   </div>
                </div>
             </div>
          </div>
         </form>
       </div>
       <div class="flex flex-col justify-between items-center gap-[5px] w-[100%] mt-[30px] ">
          <div class="w-[100%] overflow-x-scroll tableScroll">
             <table
                class="w-[100%] border-collapse border-spacing-0 rounded-[10px] border-separate border border-[#E6E6E6]">
                <tr>
                  <th
                      class="bg-[#F6F6F6] rounded-tl-[10px] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap ">
                      Click Id
                   </th>
                   <th
                      class=" whitespace-normal breakword bg-[#F6F6F6] rounded-tr-[10px] text-[10px] text-center font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left">
                      Conversion Id
                   </th>
                   <th
                      class="bg-[#F6F6F6] rounded-tl-[10px] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap ">
                      Click Date
                   </th>
                   <th
                      class="bg-[#F6F6F6] rounded-tl-[10px] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap ">
                      Conversion Date
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Status
                   </th>
                   <th
                      class="bigcontent whitespace-normal breakword bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left">
                      Offer
                   </th>
                   <th
                      class="bigcontent whitespace-normal breakword bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left">
                      Goal
                   </th>
                   <th
                      class="bigcontent whitespace-normal breakword bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left">
                      Payout
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Country
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      IP
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      OS
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Device
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Mobile ISP
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      User Agent
                   </th>
                </tr>
                <?php if(!empty($allConversions['conversions'])): ?>
                <?php $__currentLoopData = $allConversions['conversions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      <?php echo e($conversion['clickid']); ?>

                   </td>
                   <td title="AU - Ipsos iSay (TOI) [Responsive]" 
                      class="bigcontent  whitespace-normal breakword text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left  ">
                      <?php echo e($conversion['conversion_id']); ?>

                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left  ">
                      <?php echo e($conversion['click_time']); ?>

                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left  ">
                      <?php echo e($conversion['created_at']); ?>

                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      <?php if($conversion['status']=='confirmed'): ?>
                      <div class="inline-flex bg-[#F3FEE7] border border-[#BCEE89] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#6EBF1A] text-center uppercase">
                        <?php echo e($conversion['status']); ?> </div>
                      <?php else: ?>
                      <div class="inline-flex bg-[#fee7e7] border border-[#ee8989] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#bf1a1a] text-center uppercase">
                        <?php echo e($conversion['status']); ?> </div>
                      <?php endif; ?>
                      
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                      <?php echo e($conversion['offer']['title']); ?>

                   </td>
                     <?php
                        $goalConv = ($conversion['goal'] == '') ? '--' : $conversion['goal'];
                     ?>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                       <?php echo e($goalConv); ?>

                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                       $ <?php echo e($conversion['payouts']); ?>

                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                       <?php echo e($conversion['country_name']); ?>

                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                       <?php echo e($conversion['ip']); ?>

                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                       <?php echo e($conversion['os']); ?>

                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                       <?php echo e($conversion['device']); ?>

                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap ">
                       <?php echo e($conversion['isp_code']); ?>

                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] text-center px-[10px] py-[10px] text-left  ">
                      <?php echo e($conversion['ua']); ?>

                   </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
             </table>
          </div>
          
          <div class="pagination mt-[20px] flex flex-wrap gap-[10px] items-center justify-end">
            <?php if($prevPage): ?>
            <?php 
            $urlForPagination['page'] =$prevPage;
            ?>
                <a href="<?php echo e(route('report.conversions', $urlForPagination)); ?>" class="btn group inline-flex gap-[8px] items-center bg-[#F5EAF5] border border-[#FED5C3] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#D272D2] text-center hover:bg-[#D272D2] hover:text-[#fff]">
                    <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 1L1 5L5 9" stroke="#D272D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="group-hover:stroke-[#fff]" />
                    </svg> Previous
                </a>
            <?php endif; ?>
               
            <?php
               
                $totalPages = ceil($totalCount / $perPage);
                $range = 3; // Number of pages to display before and after the current page
                $start = max($currentPage - $range, 1);
                $end = min($currentPage + $range, $totalPages);
            ?>
        
            <?php if($start > 1): ?>
            <?php 
            $urlForPagination['page'] =1;
            ?>
                <a href="<?php echo e(route('report.conversions', $urlForPagination)); ?>" class="btn inline-flex gap-[8px] items-center bg-[#fff] border border-[#E6E6E6] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#808080] text-center hover:bg-[#D272D2] hover:text-[#fff]">
                    1
                </a>
                <?php if($start > 2): ?>
                    <span class="text-[#808080] px-[5px]">...</span>
                <?php endif; ?>
            <?php endif; ?>
        
            <?php for($i = $start; $i <= $end; $i++): ?>
            <?php 
            $urlForPagination['page'] =$i;
            ?>
                <a href="<?php echo e(route('report.conversions', $urlForPagination)); ?>" class="<?php echo e($i == $currentPage ? 'btn-active btn inline-flex gap-[8px] items-center bg-[#fff] border border-[#E6E6E6] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#808080] text-center hover:bg-[#D272D2] hover:text-[#fff]' : 'btn inline-flex gap-[8px] items-center bg-[#fff] border border-[#E6E6E6] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#808080] text-center hover:bg-[#D272D2] hover:text-[#fff]'); ?>">
                    <?php echo e($i); ?>

                </a>
            <?php endfor; ?>
        
            <?php if($end < $totalPages): ?>
                <?php if($end < $totalPages - 1): ?>
                    <span class="text-[#808080] px-[5px]">...</span>
                <?php endif; ?>
                <?php 
               $urlForPagination['page'] =$totalPages;
               ?>
                <a href="<?php echo e(route('report.conversions', $urlForPagination)); ?>" class="btn inline-flex gap-[8px] items-center bg-[#fff] border border-[#E6E6E6] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#808080] text-center hover:bg-[#D272D2] hover:text-[#fff]">
                    <?php echo e($totalPages); ?>

                </a>
            <?php endif; ?>
        
            <?php if($nextPage): ?>
            <?php 
            $urlForPagination['page'] =$nextPage;
            ?>
                <a href="<?php echo e(route('report.conversions', $urlForPagination)); ?>" class="btn group inline-flex gap-[5px] items-center bg-[#F5EAF5] border border-[#FED5C3] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#D272D2] text-center hover:bg-[#D272D2] hover:text-[#fff]">
                    Next
                    <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1L5 5L1 9" stroke="#D272D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="group-hover:stroke-[#fff]" />
                    </svg>
                </a>
            <?php endif; ?>
        </div>
       </div>
    </div>
 </div>
<script>
    $(document).ready(function() {
      $('.offerOption').select2({
         placeholder: "Select an offer",
         allowClear: true // Adds a clear (X) button
      });
      $('.countryOptions').select2({
         placeholder: "Select country",
         allowClear: true // Adds a clear (X) button
      });
      $('.osOption').select2({
         placeholder: "Select OS",
         allowClear: true // Adds a clear (X) button
      });
      $('.conversionstatusOption').select2({
         placeholder: "Select status",
         allowClear: true // Adds a clear (X) button
      });
      $('.appendAffiliateApps').select2({
         placeholder: "Select an app",
         allowClear: true // Adds a clear (X) button
      });
   });
   $('#filterConversions').on('submit',function(){
      $('.loader-fcustm').show();
   })
   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahulchouhan/Workspace/offerwall-affiliate/resources/views/reports/conversions.blade.php ENDPATH**/ ?>
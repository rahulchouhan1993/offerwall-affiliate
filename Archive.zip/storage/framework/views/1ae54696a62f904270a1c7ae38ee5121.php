<?php $__env->startSection('content'); ?>
<p>You will find <b>conversions</b> file in resources/views/reports/conversions.blade.php</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahulchouhan/Workspace/offerWall/resources/views/reports/conversions.blade.php ENDPATH**/ ?>